import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  FileText, Image as ImgIcon, Presentation, X, Layers, Sparkles,
  Eye, ExternalLink, Link2, Terminal, MoreHorizontal, Plus, Minus,
  Maximize, HelpCircle, ArrowRight, ChevronRight, Play, GitBranch,
  Filter, Folder, FolderOpen, Clock, CheckCircle2, AlertCircle,
  RotateCcw, Zap, Send, ChevronDown, ChevronUp, Flag, BookOpen,
  SplitSquareHorizontal, History, FileCheck, Info, Loader, Check
} from "lucide-react";

// ─────────────────────── TYPES ──────────────────────────────────

type NodeType = "source" | "working" | "generated" | "context" | "run" | "decision";
type RunStatus = "idle" | "queued" | "running" | "waiting_input" | "review" | "completed";
type PanelType = "none" | "inspector" | "preview" | "command" | "activity" | "compare";
type MinimapSize = "compact" | "standard";

interface NodeData {
  id: string; type: NodeType; title: string; subtitle: string; fileExt?: string;
  x: number; y: number; w: number; h: number;
}
interface EdgeData { from: string; to: string; dashed?: boolean; ai?: boolean; }
interface Workspace { id: string; label: string; camX: number; camY: number; }

// ─────────────────────── CONSTANTS ──────────────────────────────

const MENU_H = 30;

const PANEL_W: Record<PanelType, number> = {
  none: 0, inspector: 288, preview: 340, command: 368, activity: 320, compare: 580,
};

const MAP_SIZES: Record<MinimapSize, { w: number; h: number }> = {
  compact:  { w: 128, h: 76 },
  standard: { w: 172, h: 100 },
};

const WORKSPACES: Workspace[] = [
  { id: "understand", label: "Understand", camX: 60,    camY: 80  },
  { id: "research",   label: "Research",   camX: -1180, camY: 80  },
  { id: "produce",    label: "Produce",    camX: -2420, camY: 80  },
  { id: "review",     label: "Review",     camX: -3660, camY: 80  },
];

const CATEGORY_FILTERS = [
  { id: "source", label: "Source", types: ["source"] as NodeType[] },
  { id: "target", label: "Target", types: ["working"] as NodeType[] },
  { id: "review", label: "Review", types: ["generated"] as NodeType[] },
  { id: "return", label: "Return", types: ["decision", "context"] as NodeType[] },
];

const INITIAL_NODES: NodeData[] = [
  { id: "s1", type: "source",    title: "客户反馈.md",     subtitle: "Source",   fileExt: "md",   x: 110, y: 160, w: 168, h: 58 },
  { id: "s2", type: "source",    title: "品牌Brief.pptx",  subtitle: "Source",   fileExt: "pptx", x: 110, y: 258, w: 168, h: 58 },
  { id: "s3", type: "source",    title: "参考构图.jpg",    subtitle: "Source",   fileExt: "jpg",  x: 110, y: 356, w: 168, h: 58 },
  { id: "c1", type: "context",   title: "视觉风格指南",    subtitle: "Context",  fileExt: "pdf",  x: 400, y: 80,  w: 168, h: 50 },
  { id: "w1", type: "working",   title: "当前提案.pptx",   subtitle: "Current",  fileExt: "pptx", x: 400, y: 258, w: 168, h: 58 },
  { id: "d1", type: "decision",  title: "方向确认 Point",  subtitle: "Decision", fileExt: "",     x: 400, y: 380, w: 168, h: 50 },
  { id: "g1", type: "generated", title: "提案_v7_AI.pptx", subtitle: "Draft",    fileExt: "pptx", x: 710, y: 258, w: 168, h: 58 },
  { id: "r1", type: "run",       title: "Run #07",         subtitle: "Completed",fileExt: "",     x: 710, y: 354, w: 168, h: 42 },
];

const INITIAL_EDGES: EdgeData[] = [
  { from: "s1", to: "w1" }, { from: "s2", to: "w1" }, { from: "s3", to: "w1" },
  { from: "c1", to: "w1", dashed: true },
  { from: "w1", to: "d1" },
  { from: "w1", to: "g1", ai: true, dashed: true },
  { from: "g1", to: "r1", dashed: true },
];

const TYPE_CFG = {
  source:    { edge: "#7BA3C8", dot: "#5A8AB5", tint: "rgba(123,163,200,0.055)", label: "Source"   },
  working:   { edge: "#3A7FD5", dot: "#3A7FD5", tint: "rgba(58,127,213,0.055)",  label: "Current"  },
  generated: { edge: "#9370E8", dot: "#8B5CF6", tint: "rgba(147,112,232,0.06)",  label: "Draft"    },
  context:   { edge: "#4DA8A4", dot: "#4DA8A4", tint: "rgba(77,168,164,0.05)",   label: "Context"  },
  decision:  { edge: "#BFA03C", dot: "#BFA03C", tint: "rgba(191,160,60,0.05)",   label: "Decision" },
  run:       { edge: "#8A9BB0", dot: "#8A9BB0", tint: "rgba(138,155,176,0.04)",  label: "Run"      },
} as const;

const PROTO_PROJECTS = [
  { id: "portasplit", name: "PortaSplit",        ws: "Understand", nodes: 8, updated: "10 min ago" },
  { id: "brandlab",   name: "Brand Lab 2026",    ws: "Research",   nodes: 4, updated: "Yesterday"  },
];

// ─────────────────────── GLOBAL CSS ────────────────────────────

const GCSS = `
  body { margin: 0; overflow: hidden; font-family: 'Inter', system-ui, sans-serif; }

  .porcelain-card {
    background: #F8F8F5;
    box-shadow:
      inset 0 1px 0 rgba(255,255,255,0.88),
      inset 0 -1px 0 rgba(25,40,55,0.03),
      0 1px 2px rgba(25,40,55,0.035),
      0 3px 12px rgba(25,40,55,0.055),
      0 0 0 1px rgba(25,40,55,0.065);
    transition: box-shadow 0.12s ease;
  }
  .porcelain-card:hover {
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.92), inset 0 -1px 0 rgba(25,40,55,0.03),
      0 1px 3px rgba(25,40,55,0.05), 0 6px 20px rgba(25,40,55,0.08), 0 0 0 1px rgba(25,40,55,0.09);
  }
  .porcelain-card-sel {
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.92), 0 1px 3px rgba(25,40,55,0.05),
      0 6px 24px rgba(25,40,55,0.09), 0 0 0 1.5px rgba(25,40,55,0.32) !important;
  }
  .porcelain-card-pending {
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.92), 0 0 0 1.5px #D4845A,
      0 0 12px rgba(212,132,90,0.25), 0 3px 12px rgba(25,40,55,0.055) !important;
  }

  .float-ctrl {
    background: rgba(247,247,244,0.9);
    backdrop-filter: blur(14px) saturate(1.4);
    -webkit-backdrop-filter: blur(14px) saturate(1.4);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.7), 0 4px 24px rgba(25,40,55,0.1), 0 0 0 1px rgba(25,40,55,0.075);
  }

  .liquid-chrome {
    background: linear-gradient(145deg, #f0f0ee 0%, #ffffff 35%, #f4f4f2 60%, #e8e8e6 100%);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.9), 0 1px 4px rgba(25,40,55,0.12), 0 0 0 1px rgba(25,40,55,0.1);
    transition: box-shadow 0.1s ease, transform 0.08s ease;
  }
  .liquid-chrome:hover { box-shadow: inset 0 1px 0 rgba(255,255,255,0.95), 0 2px 8px rgba(25,40,55,0.16), 0 0 0 1px rgba(25,40,55,0.12); transform: translateY(-0.5px); }
  .liquid-chrome:active { transform: translateY(0); }

  .liquid-chrome-accent {
    background: linear-gradient(145deg, #8B68EA 0%, #9B78FF 30%, #7342E2 65%, #6230C8 100%);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.25), 0 2px 8px rgba(115,66,226,0.35), 0 0 0 1px rgba(115,66,226,0.3);
    transition: box-shadow 0.1s ease, transform 0.08s ease;
  }
  .liquid-chrome-accent:hover { box-shadow: inset 0 1px 0 rgba(255,255,255,0.3), 0 4px 14px rgba(115,66,226,0.45), 0 0 0 1px rgba(115,66,226,0.35); transform: translateY(-0.5px); }
  .liquid-chrome-accent:active { transform: translateY(0); }

  .topbar {
    background: rgba(246,246,243,0.9);
    backdrop-filter: blur(16px) saturate(1.5);
    -webkit-backdrop-filter: blur(16px) saturate(1.5);
    border-bottom: 1px solid rgba(25,40,55,0.065);
    box-shadow: 0 1px 0 rgba(255,255,255,0.5);
  }
  .dot-grid {
    background-image: radial-gradient(circle, rgba(25,40,55,0.06) 1px, transparent 1px);
    background-size: 24px 24px;
  }
  .hover-menu {
    background: rgba(248,248,245,0.97);
    backdrop-filter: blur(12px);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.8), 0 2px 12px rgba(25,40,55,0.09), 0 0 0 1px rgba(25,40,55,0.07);
    border-radius: 10px; padding: 3px; display: flex; align-items: center; gap: 1px;
  }
  .hover-menu-btn {
    display: flex; align-items: center; gap: 3px; padding: 4px 6px; border-radius: 7px;
    border: none; background: transparent; color: #8A9299; cursor: pointer;
    font-size: 9px; font-family: inherit; font-weight: 500; white-space: nowrap;
    transition: background 0.1s, color 0.1s;
  }
  .hover-menu-btn:hover { background: rgba(25,40,55,0.07); color: #192837; }

  .right-panel {
    background: #F8F8F5;
    border-left: 1px solid rgba(25,40,55,0.07);
    box-shadow: -4px 0 24px rgba(25,40,55,0.08);
  }
  .panel-header {
    padding: 14px 16px 12px;
    border-bottom: 1px solid rgba(25,40,55,0.06);
  }
  .panel-section {
    padding: 12px 16px;
    border-bottom: 1px solid rgba(25,40,55,0.05);
  }
  .proto-badge {
    font-size: 7.5px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase;
    color: rgba(138,146,153,0.5); text-align: center; padding: 6px 0; user-select: none;
  }

  .tab-item {
    display: flex; align-items: center; gap: 5px; padding: 0 10px 0 12px; height: 36px;
    border-right: 1px solid rgba(25,40,55,0.07); cursor: pointer; user-select: none;
    transition: background 0.1s;
  }
  .tab-item-active { background: rgba(255,255,255,0.6); }
  .tab-item:not(.tab-item-active):hover { background: rgba(25,40,55,0.04); }

  .run-badge-queued  { background: rgba(138,155,176,0.15); color: #8A9BB0; }
  .run-badge-running { background: rgba(58,127,213,0.12);  color: #3A7FD5; }
  .run-badge-waiting { background: rgba(212,132,90,0.14);  color: #C4703A; }
  .run-badge-review  { background: rgba(77,168,164,0.12);  color: #4DA8A4; }
  .run-badge-done    { background: rgba(107,175,107,0.12); color: #4D9E4D; }

  .minimap-panel { transition: opacity 0.2s ease; }
  .minimap-panel:not(:hover) { opacity: 0.68; }
  .minimap-panel:hover { opacity: 1; }

  .ckpt-banner {
    background: linear-gradient(135deg, rgba(191,160,60,0.12) 0%, rgba(212,168,60,0.08) 100%);
    border-bottom: 1px solid rgba(191,160,60,0.2);
    box-shadow: 0 1px 0 rgba(255,255,255,0.6);
  }

  .compare-thumb {
    border-radius: 8px; overflow: hidden;
    border: 1px solid rgba(25,40,55,0.07);
    box-shadow: 0 2px 8px rgba(25,40,55,0.06);
  }

  @keyframes fadeInUp { from { opacity:0; transform:translateY(4px); } to { opacity:1; transform:translateY(0); } }
  .fade-up { animation: fadeInUp 0.15s cubic-bezier(0.16,1,0.3,1) forwards; }
  @keyframes fadeIn { from { opacity:0; } to { opacity:1; } }
  .fade-in { animation: fadeIn 0.18s ease forwards; }
  @keyframes pulseDot { 0%,100%{opacity:1;} 50%{opacity:0.4;} }
  .pulse { animation: pulseDot 2.2s ease infinite; }
  @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
  .spin { animation: spin 1.4s linear infinite; }
  @keyframes flowLine { 0%{stroke-dashoffset:0;} 100%{stroke-dashoffset:-24;} }
  .edge-ai { animation: flowLine 2.2s linear infinite; }
  @keyframes pendingRing { 0%,100%{opacity:0.6;} 50%{opacity:1;} }
  .pending-ring { animation: pendingRing 2s ease infinite; }
  ::-webkit-scrollbar { display: none; }
`;

// ─────────────────────── FILE ICON ─────────────────────────────

function FileIcon({ ext, size = 13, color = "#9AA3AC" }: { ext?: string; size?: number; color?: string }) {
  if (ext === "jpg" || ext === "png") return <ImgIcon size={size} color={color} />;
  if (ext === "pptx")                 return <Presentation size={size} color={color} />;
  if (ext === "md" || ext === "pdf")  return <FileText size={size} color={color} />;
  return <GitBranch size={size} color={color} />;
}

// ─────────────────────── APP ────────────────────────────────────

export default function App() {
  // ── Canvas state (all preserved from V8) ──
  const [nodes,  setNodes]  = useState<NodeData[]>(INITIAL_NODES);
  const [edges,  setEdges]  = useState<EdgeData[]>(INITIAL_EDGES);
  const [camera, setCamera] = useState({ x: 60, y: 80, z: 1 });
  const [activeWs, setActiveWs] = useState("understand");
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  const [winSize, setWinSize] = useState({
    w: typeof window !== "undefined" ? window.innerWidth  : 1440,
    h: typeof window !== "undefined" ? window.innerHeight : 900,
  });
  const [selNodeId,    setSelNodeId]    = useState<string | null>(null);
  const [hoverNodeId,  setHoverNodeId]  = useState<string | null>(null);
  const [infoNodeId,   setInfoNodeId]   = useState<string | null>(null);
  const [toast,        setToast]        = useState<string | null>(null);

  // ── View / panel state (new in V9) ──
  const [appView,   setAppView]   = useState<"nav" | "canvas">("canvas");
  const [openTabs,  setOpenTabs]  = useState(["PortaSplit"]);
  const [panel,     setPanel]     = useState<PanelType>("none");
  const [panelNodeId, setPanelNodeId] = useState<string | null>(null);

  // ── Run simulation state ──
  const [runStatus,   setRunStatus]   = useState<RunStatus>("idle");
  const [runNumber,   setRunNumber]   = useState(8);
  const [pendingArtifactId, setPendingArtifactId] = useState<string | null>(null);
  const [checkpointBanner,  setCheckpointBanner]  = useState(false);

  // ── Command panel state ──
  const [commandTargetId, setCommandTargetId] = useState<string>("w1");
  const [commandCtxIds,   setCommandCtxIds]   = useState<string[]>(["c1"]);
  const [commandTask,     setCommandTask]     = useState("");
  const [advancedOpen,    setAdvancedOpen]    = useState(false);

  // ── Preview panel state ──
  const [previewPage, setPreviewPage] = useState(1);
  const [notes, setNotes] = useState<Record<string, string>>({});

  // ── Minimap state ──
  const [minimapSize, setMinimapSize] = useState<MinimapSize>("compact");

  // ── Refs ──
  const wrapperRef  = useRef<HTMLDivElement>(null);
  const animRef     = useRef<number | null>(null);
  const runTimers   = useRef<ReturnType<typeof setTimeout>[]>([]);
  const cameraRef   = useRef(camera);
  useEffect(() => { cameraRef.current = camera; }, [camera]);

  const dragRef = useRef<{
    type: "pan" | "node" | "minimap" | null;
    id?: string; startX: number; startY: number; initX: number; initY: number; moved: boolean;
  }>({ type: null, startX: 0, startY: 0, initX: 0, initY: 0, moved: false });

  // ── Cleanup timers on unmount ──
  useEffect(() => () => { runTimers.current.forEach(clearTimeout); }, []);

  // ── Resize ──
  useEffect(() => {
    const fn = () => setWinSize({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener("resize", fn);
    return () => window.removeEventListener("resize", fn);
  }, []);

  // ── Wheel zoom/pan ──
  useEffect(() => {
    if (appView !== "canvas") return;
    const el = wrapperRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      if (e.ctrlKey || e.metaKey) {
        const dz = -e.deltaY * 0.005;
        setCamera(c => {
          const newZ = Math.max(0.15, Math.min(c.z + dz, 4));
          const rect = el.getBoundingClientRect();
          const mx = e.clientX - rect.left, my = e.clientY - rect.top;
          return { x: c.x - (mx - c.x) * (newZ / c.z - 1), y: c.y - (my - c.y) * (newZ / c.z - 1), z: newZ };
        });
      } else {
        setCamera(c => ({ ...c, x: c.x - e.deltaX, y: c.y - e.deltaY }));
      }
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [appView]);

  // ── Keyboard shortcuts ──
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === "Escape") { closeAllPanels(); setInfoNodeId(null); }
      if (appView !== "canvas") return;
      if ((e.key === "c" || e.key === "C") && selNodeId) {
        e.preventDefault();
        openPanel("command", selNodeId);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appView, selNodeId]);

  // ── Panel management ──
  const closeAllPanels = () => setPanel("none");

  const openPanel = (type: PanelType, nodeId?: string) => {
    setPanel(type);
    if (nodeId !== undefined) setPanelNodeId(nodeId);
    if (type === "command" && nodeId) {
      setCommandTargetId(nodeId);
      setCommandTask("");
      setAdvancedOpen(false);
    }
    if (type === "preview") setPreviewPage(1);
    setInfoNodeId(null);
  };

  // ── Toast ──
  const fireToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2400);
  };

  // ── Run simulation ──
  const clearRunTimers = () => { runTimers.current.forEach(clearTimeout); runTimers.current = []; };

  const startRun = () => {
    clearRunTimers();
    const n = runNumber;
    setRunStatus("queued");
    openPanel("activity");
    runTimers.current.push(setTimeout(() => setRunStatus("running"), 1200));
    runTimers.current.push(setTimeout(() => setRunStatus("waiting_input"), 4000));
    void n;
  };

  const respondWaiting = (action: "save" | "overwrite" | "cancel") => {
    if (action === "cancel") { setRunStatus("idle"); return; }
    setRunStatus("review");
    runTimers.current.push(setTimeout(() => {
      const artId = `art${runNumber}`;
      const targetNode = nodes.find(n => n.id === commandTargetId) || nodes.find(n => n.id === "w1")!;
      setNodes(prev => [...prev, {
        id: artId, type: "generated", title: `提案_v${runNumber}_AI.pptx`,
        subtitle: "Pending Return", fileExt: "pptx",
        x: targetNode.x + 10, y: targetNode.y + 130, w: 168, h: 58,
      }]);
      setEdges(prev => [...prev, { from: "r1", to: artId, dashed: true, ai: true }]);
      setPendingArtifactId(artId);
      setRunStatus("completed");
      setRunNumber(n => n + 1);
      openPanel("compare", artId);
    }, 1800));
  };

  const acceptArtifact = () => {
    if (pendingArtifactId) {
      setNodes(prev => prev.map(n => n.id === pendingArtifactId ? { ...n, subtitle: "Accepted — Draft" } : n));
    }
    setPendingArtifactId(null);
    closeAllPanels();
    setTimeout(() => setCheckpointBanner(true), 400);
  };

  const createCheckpoint = () => {
    setCheckpointBanner(false);
    setNodes(prev => [...prev, {
      id: "ckpt1", type: "decision", title: `Checkpoint · Run #${runNumber - 1}`,
      subtitle: "Checkpoint", fileExt: "",
      x: 400, y: 480, w: 180, h: 50,
    }]);
    fireToast("Checkpoint 已创建");
  };

  // ── Content bounds + camera clamp (minimap only) ──
  const getContentBounds = useCallback(() => {
    let mnX = Infinity, mnY = Infinity, mxX = -Infinity, mxY = -Infinity;
    nodes.forEach(n => { mnX = Math.min(mnX, n.x); mnY = Math.min(mnY, n.y); mxX = Math.max(mxX, n.x + n.w); mxY = Math.max(mxY, n.y + n.h); });
    return mnX === Infinity ? null : { mnX, mnY, mxX, mxY };
  }, [nodes]);

  const clampCam = useCallback((x: number, y: number, z: number) => {
    const b = getContentBounds();
    if (!b) return { x, y };
    const pad = 220;
    return {
      x: Math.max(-(b.mxX + pad) * z + winSize.w * 0.12, Math.min(-(b.mnX - pad) * z + winSize.w * 0.88, x)),
      y: Math.max(-(b.mxY + pad) * z + winSize.h * 0.12, Math.min(-(b.mnY - pad) * z + winSize.h * 0.88, y)),
    };
  }, [getContentBounds, winSize]);

  // ── Workspace smooth pan ──
  const switchWorkspace = useCallback((ws: Workspace) => {
    setActiveWs(ws.id);
    if (animRef.current) cancelAnimationFrame(animRef.current);
    const snap = { ...cameraRef.current };
    const duration = 430;
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const e = 1 - Math.pow(1 - t, 3);
      setCamera(c => ({ ...c, x: snap.x + (ws.camX - snap.x) * e, y: snap.y + (ws.camY - snap.y) * e }));
      if (t < 1) animRef.current = requestAnimationFrame(tick);
    };
    animRef.current = requestAnimationFrame(tick);
  }, []);

  // ── Drag handlers ──
  const onPointerDownCanvas = (e: React.PointerEvent) => {
    dragRef.current = { type: "pan", startX: e.clientX, startY: e.clientY, initX: camera.x, initY: camera.y, moved: false };
    setInfoNodeId(null); setSelNodeId(null);
  };

  const onPointerDownNode = (e: React.PointerEvent, node: NodeData) => {
    e.stopPropagation();
    dragRef.current = { type: "node", id: node.id, startX: e.clientX, startY: e.clientY, initX: node.x, initY: node.y, moved: false };
    setInfoNodeId(null);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    const s = dragRef.current;
    if (!s.type) return;
    const dx = e.clientX - s.startX, dy = e.clientY - s.startY;
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) s.moved = true;
    if (s.type === "pan") {
      setCamera(c => ({ ...c, x: s.initX + dx, y: s.initY + dy }));
    } else if (s.type === "node") {
      setNodes(ns => ns.map(n => n.id === s.id ? { ...n, x: s.initX + dx / camera.z, y: s.initY + dy / camera.z } : n));
    } else if (s.type === "minimap") {
      const raw = { x: s.initX - (dx / scaleM) * camera.z, y: s.initY - (dy / scaleM) * camera.z };
      setCamera(c => ({ ...c, ...clampCam(raw.x, raw.y, c.z) }));
    }
  };

  const onPointerUp = () => {
    const s = dragRef.current;
    if (s.type === "node" && !s.moved && s.id) setSelNodeId(s.id);
    dragRef.current = { type: null, startX: 0, startY: 0, initX: 0, initY: 0, moved: false };
  };

  // ── Minimap ──
  const mapDims = MAP_SIZES[minimapSize];
  const MAP_W = mapDims.w, MAP_H = mapDims.h;
  const WORLD = { x: -300, y: -150, w: 2400, h: 1400 };
  const scaleM = MAP_W / WORLD.w;

  const onPointerDownMinimap = (e: React.PointerEvent) => {
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    const vx = (-camera.x / camera.z - WORLD.x) * scaleM;
    const vy = (-camera.y / camera.z - WORLD.y) * scaleM;
    const vw = (winSize.w / camera.z) * scaleM, vh = (winSize.h / camera.z) * scaleM;
    if (mx >= vx && mx <= vx + vw && my >= vy && my <= vy + vh) {
      dragRef.current = { type: "minimap", startX: e.clientX, startY: e.clientY, initX: camera.x, initY: camera.y, moved: false };
    } else {
      let twx = mx / scaleM + WORLD.x, twy = my / scaleM + WORLD.y;
      const b = getContentBounds();
      if (b) { twx = Math.max(b.mnX - 180, Math.min(b.mxX + 180, twx)); twy = Math.max(b.mnY - 180, Math.min(b.mxY + 180, twy)); }
      const nx = -twx * camera.z + winSize.w / 2, ny = -twy * camera.z + winSize.h / 2;
      const c = clampCam(nx, ny, camera.z);
      setCamera(p => ({ ...p, ...c }));
      dragRef.current = { type: "minimap", startX: e.clientX, startY: e.clientY, initX: c.x, initY: c.y, moved: false };
    }
  };

  const handleFit = () => {
    let mnX = Infinity, mnY = Infinity, mxX = -Infinity, mxY = -Infinity;
    nodes.forEach(n => { mnX = Math.min(mnX, n.x); mnY = Math.min(mnY, n.y); mxX = Math.max(mxX, n.x + n.w); mxY = Math.max(mxY, n.y + n.h); });
    if (mnX === Infinity) return;
    const pad = 120, w = mxX - mnX + pad * 2, h = mxY - mnY + pad * 2;
    const z = Math.min(winSize.w / w, winSize.h / h, 2);
    setCamera({ x: -(mnX - pad) * z + (winSize.w - w * z) / 2, y: -(mnY - pad) * z + (winSize.h - h * z) / 2, z });
  };

  // ── Filter ──
  const isFiltered = (node: NodeData) => {
    if (!activeFilter) return false;
    const f = CATEGORY_FILTERS.find(c => c.id === activeFilter);
    return f ? !f.types.includes(node.type) : false;
  };

  // ── Screen-space position ──
  const nodeScreenRect = (node: NodeData) => ({
    x: node.x * camera.z + camera.x, y: node.y * camera.z + camera.y,
    w: node.w * camera.z, h: node.h * camera.z,
  });

  // ── Run status badge config ──
  const runBadge = {
    idle:          null,
    queued:        { cls: "run-badge-queued",  label: "Queued",          icon: <Clock size={9}/> },
    running:       { cls: "run-badge-running", label: `Run #${runNumber} Running`, icon: <Loader size={9} className="spin"/> },
    waiting_input: { cls: "run-badge-waiting", label: "Waiting Input",   icon: <AlertCircle size={9}/> },
    review:        { cls: "run-badge-review",  label: "Reviewing",       icon: <CheckCircle2 size={9}/> },
    completed:     { cls: "run-badge-done",    label: "Completed",       icon: <CheckCircle2 size={9}/> },
  }[runStatus];

  // ── SVG Edges ──
  const renderEdges = () => (
    <svg className="absolute inset-0 pointer-events-none overflow-visible" style={{ zIndex: 0 }}>
      <defs>
        <marker id="arr" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto">
          <path d="M0,1 L6,3.5 L0,6 Z" fill="rgba(25,40,55,0.14)" />
        </marker>
        <marker id="arr-ai" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto">
          <path d="M0,1 L6,3.5 L0,6 Z" fill="rgba(147,112,232,0.5)" />
        </marker>
      </defs>
      {edges.map((edge, i) => {
        const fn = nodes.find(n => n.id === edge.from);
        const tn = nodes.find(n => n.id === edge.to);
        if (!fn || !tn) return null;
        const x1 = fn.x + fn.w, y1 = fn.y + fn.h / 2;
        const x2 = tn.x,        y2 = tn.y + tn.h / 2;
        const cpX = (x1 + x2) / 2;
        const d = `M ${x1} ${y1} C ${cpX} ${y1}, ${cpX} ${y2}, ${x2} ${y2}`;
        const isAI = edge.ai;
        const isSel = selNodeId === edge.from || selNodeId === edge.to;
        return (
          <path key={i} d={d} fill="none"
            stroke={isAI ? (isSel ? "rgba(147,112,232,0.6)" : "rgba(147,112,232,0.28)") : (isSel ? "rgba(25,40,55,0.24)" : "rgba(25,40,55,0.1)")}
            strokeWidth={isSel ? "1.5" : "1"}
            strokeDasharray={edge.dashed ? (isAI ? "6 4" : "3.5 3") : "none"}
            className={isAI ? "edge-ai" : ""}
            markerEnd={isAI ? "url(#arr-ai)" : "url(#arr)"}
          />
        );
      })}
    </svg>
  );

  // ─────────────────────── RENDER ─────────────────────────────────

  return (
    <div className="fixed inset-0 overflow-hidden" style={{ background: "#ECEDEA" }}>
      <style dangerouslySetInnerHTML={{ __html: GCSS }} />

      {/* ══ PROJECT NAV OVERLAY ══════════════════════════════════ */}
      {appView === "nav" && (
        <div className="fixed inset-0 z-50 flex flex-col" style={{ background: "#F0F0ED" }}>
          <div className="topbar fixed top-0 left-0 right-0 h-9 z-10 flex items-center px-6 gap-3">
            <div className="flex items-center gap-1.5 select-none">
              <div className="w-5 h-5 rounded-md flex items-center justify-center" style={{ background: "rgba(115,66,226,0.1)" }}>
                <Layers size={11} color="#7342E2" />
              </div>
              <span className="text-[10px] font-bold tracking-[0.14em] uppercase text-[#192837] opacity-70">Local OS</span>
            </div>
            <div className="flex-1" />
            <span className="text-[9px] text-[#8A9299] select-none">Alpha 0.1 · PROTOTYPE DATA</span>
          </div>

          <div className="flex-1 flex items-center justify-center pt-9">
            <div className="w-[560px]">
              {/* Recent */}
              <div className="mb-8">
                <div className="text-[9.5px] font-bold uppercase tracking-[0.14em] text-[#8A9299] mb-4 select-none">Continue Working</div>
                <div className="space-y-2">
                  {PROTO_PROJECTS.map(p => (
                    <button key={p.id}
                      className="w-full text-left rounded-2xl p-4 transition-all cursor-pointer group"
                      style={{
                        background: "rgba(248,248,245,0.9)",
                        boxShadow: "inset 0 1px 0 rgba(255,255,255,0.85), 0 2px 12px rgba(25,40,55,0.06), 0 0 0 1px rgba(25,40,55,0.07)",
                      }}
                      onClick={() => {
                        if (!openTabs.includes(p.name)) setOpenTabs(t => [...t, p.name]);
                        setAppView("canvas");
                      }}>
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                          style={{ background: "rgba(115,66,226,0.08)" }}>
                          <FolderOpen size={16} color="#7342E2" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-[13px] font-semibold text-[#192837] select-none">{p.name}</div>
                          <div className="text-[10px] text-[#8A9299] mt-0.5 select-none">
                            {p.ws} · {p.nodes} nodes · {p.updated}
                          </div>
                        </div>
                        <ArrowRight size={14} color="#8A9299" className="opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Start */}
              <div className="mb-6">
                <div className="text-[9.5px] font-bold uppercase tracking-[0.14em] text-[#8A9299] mb-3 select-none">Start</div>
                <div className="flex gap-2">
                  <button className="flex-1 flex items-center gap-2.5 px-4 py-3 rounded-xl cursor-pointer transition-all"
                    style={{ background: "rgba(248,248,245,0.9)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.8), 0 1px 4px rgba(25,40,55,0.06), 0 0 0 1px rgba(25,40,55,0.07)" }}
                    onClick={() => { setOpenTabs(["New Project"]); setAppView("canvas"); }}>
                    <Plus size={14} color="#7342E2" />
                    <span className="text-[11px] font-medium text-[#192837] select-none">New Blank Project</span>
                  </button>
                  <button className="flex-1 flex items-center gap-2.5 px-4 py-3 rounded-xl cursor-pointer transition-all"
                    style={{ background: "rgba(248,248,245,0.9)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.8), 0 1px 4px rgba(25,40,55,0.06), 0 0 0 1px rgba(25,40,55,0.07)" }}
                    onClick={() => fireToast("打开本地项目… (Prototype)")}>
                    <Folder size={14} color="#8A9299" />
                    <span className="text-[11px] font-medium text-[#192837] select-none">Open Local…</span>
                  </button>
                </div>
              </div>

              <div className="proto-badge">LOCAL CREATIVE OS · ALPHA 0.1 · PROTOTYPE DATA — No backend connected</div>
            </div>
          </div>
        </div>
      )}

      {/* ══ TOP BAR ══════════════════════════════════════════════ */}
      <div className="topbar fixed top-0 left-0 right-0 h-9 z-40 flex items-center">
        {/* Brand */}
        <div className="flex items-center gap-1.5 px-4 select-none flex-shrink-0">
          <div className="w-5 h-5 rounded-md flex items-center justify-center" style={{ background: "rgba(115,66,226,0.1)" }}>
            <Layers size={11} color="#7342E2" />
          </div>
          <span className="text-[10px] font-bold tracking-[0.14em] uppercase text-[#192837] opacity-70">Local OS</span>
        </div>

        {/* Tabs */}
        <div className="flex items-stretch h-full border-l border-r" style={{ borderColor: "rgba(25,40,55,0.07)" }}>
          {openTabs.map(tab => (
            <div key={tab} className="tab-item tab-item-active">
              <span className="text-[11px] font-medium text-[#192837] select-none">{tab}</span>
              <button className="w-4 h-4 flex items-center justify-center rounded hover:bg-[rgba(25,40,55,0.1)] transition-colors"
                onClick={() => {
                  const newTabs = openTabs.filter(t => t !== tab);
                  setOpenTabs(newTabs);
                  if (newTabs.length === 0) setAppView("nav");
                }}>
                <X size={9} color="#8A9299" />
              </button>
            </div>
          ))}
          <button className="tab-item"
            onClick={() => setAppView("nav")}>
            <Plus size={11} color="#8A9299" />
          </button>
        </div>

        {/* Breadcrumb */}
        {appView === "canvas" && (
          <div className="flex items-center gap-1.5 px-3 select-none">
            <ChevronRight size={11} color="rgba(25,40,55,0.3)" />
            <span className="text-[10.5px] text-[#8A9299] capitalize">{activeWs}</span>
          </div>
        )}

        <div className="flex-1" />

        {/* Run status badge */}
        {runBadge && (
          <button
            className={`flex items-center gap-1.5 px-2.5 h-6 rounded-lg mr-2 cursor-pointer text-[9.5px] font-medium ${runBadge.cls}`}
            onClick={() => openPanel("activity")}>
            {runBadge.icon}
            <span className="select-none">{runBadge.label}</span>
          </button>
        )}

        {/* New Run */}
        {appView === "canvas" && (
          <button className="liquid-chrome-accent flex items-center gap-1.5 px-2.5 h-6 rounded-md cursor-pointer mr-4"
            onClick={startRun}>
            <Play size={10} color="rgba(255,255,255,0.9)" />
            <span className="text-[10px] font-semibold text-white/90 select-none">New Run</span>
          </button>
        )}

        {appView === "canvas" && (
          <span className="text-[10px] text-[#8A9299] select-none mr-4">All saved</span>
        )}
      </div>

      {/* ── Checkpoint Banner ── */}
      {checkpointBanner && (
        <div className="ckpt-banner fixed left-0 right-0 z-45 flex items-center px-5 h-9 gap-3 fade-in" style={{ top: 36 }}>
          <Flag size={12} color="#BFA03C" />
          <span className="text-[10.5px] font-medium text-[#192837] select-none flex-1">
            建议创建 Checkpoint · 4 files changed since last stable state
          </span>
          <button className="liquid-chrome px-3 h-6 rounded-lg text-[9.5px] font-semibold text-[#192837] cursor-pointer"
            onClick={createCheckpoint}>
            Create Checkpoint
          </button>
          <button className="text-[9.5px] text-[#8A9299] cursor-pointer hover:text-[#192837] transition-colors"
            onClick={() => setCheckpointBanner(false)}>
            Later
          </button>
        </div>
      )}

      {/* ══ CANVAS VIEW ══════════════════════════════════════════ */}
      {appView === "canvas" && (
        <>
          {/* ── Workspace Dock (left) ── */}
          <div className="fixed left-5 z-40 float-ctrl rounded-2xl p-1.5 flex flex-col gap-0.5 select-none"
            style={{ top: "50%", transform: "translateY(-50%)" }}>
            <div className="px-2 pt-1 pb-0.5">
              <span className="text-[8.5px] font-bold uppercase tracking-[0.13em] text-[#8A9299]">Workspace</span>
            </div>
            {WORKSPACES.map(ws => {
              const isActive = activeWs === ws.id;
              return (
                <button key={ws.id}
                  className="flex items-center gap-2 px-2 py-1.5 rounded-xl text-left cursor-pointer transition-all"
                  style={{ background: isActive ? "rgba(25,40,55,0.06)" : "transparent", boxShadow: isActive ? "inset 0 1px 0 rgba(255,255,255,0.8), 0 1px 2px rgba(25,40,55,0.06)" : "none" }}
                  onClick={() => switchWorkspace(ws)}>
                  <div className="w-1.5 h-1.5 rounded-full transition-colors"
                    style={{ background: isActive ? "#7342E2" : "rgba(25,40,55,0.18)" }} />
                  <span className="text-[10.5px] font-medium select-none" style={{ color: isActive ? "#192837" : "#8A9299" }}>
                    {ws.label}
                  </span>
                </button>
              );
            })}
            <div className="mx-2 my-1" style={{ height: 1, background: "rgba(25,40,55,0.07)" }} />
            <div className="px-2 pb-0.5 flex items-center gap-1.5">
              <Filter size={9} color="#8A9299" />
              <span className="text-[8.5px] font-bold uppercase tracking-[0.13em] text-[#8A9299]">Filter</span>
            </div>
            {CATEGORY_FILTERS.map(f => {
              const isActive = activeFilter === f.id;
              const cfg = f.types[0] ? TYPE_CFG[f.types[0]] : null;
              return (
                <button key={f.id}
                  className="flex items-center gap-2 px-2 py-1 rounded-lg cursor-pointer transition-all text-left"
                  style={{ background: isActive ? (cfg ? `${cfg.dot}18` : "rgba(25,40,55,0.06)") : "transparent" }}
                  onClick={() => setActiveFilter(isActive ? null : f.id)}>
                  <div className="w-1 h-1 rounded-full flex-shrink-0"
                    style={{ background: isActive && cfg ? cfg.dot : "rgba(25,40,55,0.2)" }} />
                  <span className="text-[10px] font-medium select-none" style={{ color: isActive ? "#192837" : "#8A9299" }}>
                    {f.label}
                  </span>
                  {isActive && <X size={8} color="#8A9299" className="ml-auto" />}
                </button>
              );
            })}
            <div className="mx-2 my-1" style={{ height: 1, background: "rgba(25,40,55,0.07)" }} />
            <button className="liquid-chrome flex items-center justify-center gap-1 px-2 py-1.5 rounded-xl cursor-pointer">
              <Plus size={10} color="#8A9299" />
              <span className="text-[9.5px] text-[#8A9299] select-none">Add</span>
            </button>
          </div>

          {/* ── Main Canvas ── */}
          <div ref={wrapperRef} className="absolute inset-0 cursor-grab active:cursor-grabbing"
            onPointerDown={onPointerDownCanvas}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}>
            <div style={{
              transform: `translate(${camera.x}px, ${camera.y}px) scale(${camera.z})`,
              transformOrigin: "0 0", width: "100%", height: "100%", position: "absolute",
            }}>
              <div className="dot-grid absolute pointer-events-none"
                style={{ left: -5000, top: -5000, width: 10000, height: 10000 }} />
              {renderEdges()}

              {/* ── Nodes ── */}
              {nodes.map(node => {
                const isSel    = selNodeId === node.id;
                const isHov    = hoverNodeId === node.id;
                const isDraft  = node.type === "generated";
                const cfg      = TYPE_CFG[node.type];
                const dimmed   = isFiltered(node);
                const isPending = pendingArtifactId === node.id;

                const menuActions = [
                  ...(isPending ? [{ icon: <SplitSquareHorizontal size={10}/>, label: "Compare", action: () => openPanel("compare", node.id) }] : []),
                  { icon: <Eye size={10}/>,            label: "预览",    action: () => openPanel("preview", node.id) },
                  { icon: <Link2 size={10}/>,          label: "关系",    action: () => { closeAllPanels(); setPanelNodeId(node.id); setPanel("inspector"); } },
                  { icon: <Terminal size={10}/>,       label: "Command", action: () => openPanel("command", node.id) },
                  { icon: <ExternalLink size={10}/>,   label: "原生",    action: () => fireToast("正在打开原生工具…") },
                  { icon: <MoreHorizontal size={10}/>, label: "更多",    action: () => fireToast("更多选项") },
                ];

                return (
                  <div key={node.id} className="absolute"
                    style={{
                      left: node.x, top: node.y, width: node.w, height: node.h + MENU_H,
                      zIndex: isSel ? 10 : 1, opacity: dimmed ? 0.28 : 1, transition: "opacity 0.2s ease",
                    }}
                    onPointerEnter={() => { if (!dragRef.current.type) setHoverNodeId(node.id); }}
                    onPointerLeave={() => setHoverNodeId(null)}
                  >
                    {/* Card */}
                    <div
                      className={`absolute porcelain-card flex items-center gap-2.5 px-3 overflow-hidden cursor-pointer ${isSel ? "porcelain-card-sel" : ""} ${isPending ? "porcelain-card-pending" : ""}`}
                      style={{
                        top: 0, left: 0, width: "100%", height: node.h, borderRadius: 16,
                        borderLeft: `3px solid ${isPending ? "#D4845A" : cfg.edge}`,
                        background: `linear-gradient(180deg, ${cfg.tint} 0%, #F8F8F5 100%)`,
                      }}
                      onPointerDown={e => onPointerDownNode(e, node)}
                      onDoubleClick={e => {
                        e.stopPropagation();
                        closeAllPanels();
                        setPanelNodeId(node.id);
                        setPanel("inspector");
                      }}
                    >
                      <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${isDraft ? "pulse" : ""}`}
                        style={{ background: isPending ? "#D4845A" : cfg.dot }} />
                      <div className="flex-shrink-0 opacity-55"><FileIcon ext={node.fileExt} size={13} /></div>
                      <div className="flex-1 min-w-0 flex flex-col select-none">
                        <div className="text-[11px] font-semibold text-[#192837] truncate leading-tight">{node.title}</div>
                        <div className="text-[9px] font-medium mt-[1px] truncate"
                          style={{ color: isPending ? "#D4845A" : cfg.dot, opacity: 0.85 }}>
                          {isPending ? "Pending Return" : node.subtitle}
                        </div>
                      </div>
                      {isHov && (
                        <button className="w-5 h-5 flex items-center justify-center rounded-lg flex-shrink-0 fade-up"
                          style={{ background: "rgba(25,40,55,0.05)" }}
                          onClick={e => { e.stopPropagation(); setInfoNodeId(infoNodeId === node.id ? null : node.id); }}>
                          <HelpCircle size={11} color="#8A9299" />
                        </button>
                      )}
                    </div>

                    {/* Hover menu */}
                    {isHov && (
                      <div className="absolute hover-menu fade-up"
                        style={{ top: node.h + 4, left: 0 }}
                        onPointerDown={e => e.stopPropagation()}>
                        {menuActions.map(act => (
                          <button key={act.label} className="hover-menu-btn"
                            onClick={e => { e.stopPropagation(); act.action(); }}>
                            {act.icon}<span>{act.label}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* ── Mini-map (bottom-left, compact/standard) ── */}
          <div className="minimap-panel fixed bottom-5 left-5 z-40 float-ctrl rounded-2xl p-2 flex flex-col gap-1.5 select-none">
            <div className="flex items-center justify-between mb-0.5 px-0.5">
              <span className="text-[7.5px] font-bold uppercase tracking-[0.12em] text-[#8A9299] opacity-60">Canvas</span>
              <button className="text-[7.5px] text-[#8A9299] hover:text-[#192837] transition-colors cursor-pointer px-1"
                onClick={() => setMinimapSize(s => s === "compact" ? "standard" : "compact")}>
                {minimapSize === "compact" ? "⊞" : "⊟"}
              </button>
            </div>

            {/* Map surface */}
            <div className="relative rounded-xl overflow-hidden cursor-crosshair"
              style={{ width: MAP_W, height: MAP_H, background: "rgba(25,40,55,0.025)", border: "1px solid rgba(25,40,55,0.055)" }}
              onPointerDown={onPointerDownMinimap}>
              {nodes.map(n => (
                <div key={n.id} className="absolute rounded-sm"
                  style={{
                    left:   (n.x - WORLD.x) * scaleM, top:    (n.y - WORLD.y) * scaleM,
                    width:  Math.max(n.w * scaleM, 2), height: Math.max(n.h * scaleM, 1.5),
                    background: selNodeId === n.id ? "#192837" : TYPE_CFG[n.type].dot,
                    opacity: selNodeId === n.id ? 0.85 : 0.3,
                  }}
                />
              ))}
              <div className="absolute pointer-events-none" style={{
                left:   (-camera.x / camera.z - WORLD.x) * scaleM,
                top:    (-camera.y / camera.z - WORLD.y) * scaleM,
                width:  Math.max((winSize.w / camera.z) * scaleM, 4),
                height: Math.max((winSize.h / camera.z) * scaleM, 4),
                border: "1.5px solid rgba(115,66,226,0.5)", background: "rgba(115,66,226,0.04)", borderRadius: 3,
              }} />
            </div>

            {/* Controls */}
            <div className="flex items-center justify-between">
              <button className="w-6 h-6 flex items-center justify-center rounded-lg hover:bg-[rgba(25,40,55,0.07)] transition-colors cursor-pointer text-[#8A9299]"
                onClick={() => setCamera(c => { const z = Math.max(0.15, c.z - 0.2); return { ...c, z }; })}>
                <Minus size={10}/>
              </button>
              <button className="flex items-center gap-1 px-1.5 h-6 rounded-lg hover:bg-[rgba(25,40,55,0.07)] transition-colors cursor-pointer text-[#8A9299]"
                onClick={handleFit}>
                <Maximize size={9}/>
                <span className="text-[8px] font-medium">Fit</span>
              </button>
              <span className="text-[8px] text-[#8A9299] tabular-nums w-8 text-center">{Math.round(camera.z * 100)}%</span>
              <button className="liquid-chrome w-6 h-6 flex items-center justify-center rounded-lg cursor-pointer"
                onClick={() => setCamera(c => ({ ...c, z: Math.min(4, c.z + 0.2) }))}>
                <Plus size={10} color="#192837"/>
              </button>
            </div>
          </div>

          {/* ── ? Info Overlay (screen-space) ── */}
          {infoNodeId && (() => {
            const node = nodes.find(n => n.id === infoNodeId);
            if (!node) return null;
            const sr = nodeScreenRect(node);
            const cfg = TYPE_CFG[node.type];
            const isDraft = node.type === "generated";
            const oW = 212;
            const rawL = sr.x + sr.w + 10;
            const oLeft = rawL + oW > winSize.w - 8 ? sr.x - oW - 10 : rawL;
            const oTop  = Math.max(48, Math.min(sr.y, winSize.h - 260));
            const nodeEdgeCount = edges.filter(e => e.from === node.id || e.to === node.id).length;
            return (
              <div className="fixed z-50 float-ctrl rounded-2xl p-3.5 fade-up"
                style={{ left: oLeft, top: oTop, width: oW }}
                onPointerDown={e => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-3">
                  <div className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full" style={{ background: cfg.dot }} />
                    <span className="text-[8.5px] font-bold uppercase tracking-[0.13em] text-[#8A9299] select-none">{cfg.label}</span>
                  </div>
                  <button onClick={() => setInfoNodeId(null)} className="cursor-pointer text-[#8A9299] hover:text-[#192837]"><X size={11}/></button>
                </div>
                <div className="space-y-1.5 mb-3">
                  {[
                    ["来源", node.subtitle],
                    ["版本", isDraft ? "v7 (AI Draft)" : "v6"],
                    ["备注", isDraft ? "未提升为 Current" : "活跃"],
                    ["关系数", String(nodeEdgeCount)],
                    ["最近变化", "10 min ago"],
                  ].map(([k, v]) => (
                    <div key={k} className="flex justify-between items-center">
                      <span className="text-[9px] text-[#8A9299] select-none">{k}</span>
                      <span className="text-[9px] font-semibold text-[#192837] select-none">{v}</span>
                    </div>
                  ))}
                </div>
                {isDraft && (
                  <button className="liquid-chrome-accent w-full py-1.5 rounded-xl text-[9.5px] font-bold text-white cursor-pointer"
                    onClick={() => { setInfoNodeId(null); fireToast("已标记为 Current 候选 (Draft 约束生效)"); }}>
                    Promote to Current
                  </button>
                )}
              </div>
            );
          })()}
        </>
      )}

      {/* ══ RIGHT PANELS ═════════════════════════════════════════ */}

      {/* ── Relations Inspector ── */}
      {panel === "inspector" && (() => {
        const node = nodes.find(n => n.id === panelNodeId);
        if (!node) return null;
        const cfg  = TYPE_CFG[node.type];
        const rels = edges.filter(e => e.from === node.id || e.to === node.id);
        return (
          <div className="right-panel fixed z-50 flex flex-col" style={{ top: 36, right: 0, bottom: 0, width: PANEL_W.inspector }}>
            <div className="panel-header flex justify-between items-start">
              <div>
                <div className="text-[8.5px] font-bold uppercase tracking-[0.13em] text-[#8A9299] mb-1 select-none">Relations Inspector</div>
                <div className="text-[13px] font-semibold text-[#192837] select-none">{node.title}</div>
                <div className="flex items-center gap-1.5 mt-1">
                  <div className="w-1.5 h-1.5 rounded-full" style={{ background: cfg.dot }} />
                  <span className="text-[9.5px] font-medium select-none" style={{ color: cfg.dot }}>{cfg.label}</span>
                </div>
              </div>
              <button onClick={closeAllPanels} className="p-1.5 rounded-xl hover:bg-[rgba(25,40,55,0.06)] cursor-pointer text-[#8A9299]"><X size={13}/></button>
            </div>
            <div className="p-4 flex-1 overflow-y-auto">
              <div className="text-[9.5px] font-semibold uppercase tracking-[0.1em] text-[#8A9299] mb-3 select-none">
                1st-degree · {rels.length} connection{rels.length !== 1 ? "s" : ""}
              </div>
              <div className="space-y-1.5">
                {rels.map((e, i) => {
                  const isIn = e.to === node.id;
                  const relId = isIn ? e.from : e.to;
                  const rel = nodes.find(n => n.id === relId);
                  if (!rel) return null;
                  const rc = TYPE_CFG[rel.type];
                  return (
                    <button key={i}
                      className="w-full flex items-center gap-2.5 p-2.5 rounded-xl text-left cursor-pointer hover:bg-[rgba(25,40,55,0.04)] transition-colors"
                      style={{ border: "1px solid rgba(25,40,55,0.055)", background: "rgba(25,40,55,0.015)" }}
                      onClick={() => { setPanelNodeId(relId); setCamera(c => ({ ...clampCam(-rel.x * c.z + winSize.w / 2, -rel.y * c.z + winSize.h / 2, c.z), z: c.z })); }}>
                      <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: rc.dot }} />
                      <div className="flex-1 min-w-0">
                        <div className="text-[10.5px] font-medium text-[#192837] truncate select-none">{rel.title}</div>
                        <div className="text-[9px] select-none" style={{ color: rc.dot, opacity: 0.8 }}>{rc.label}</div>
                      </div>
                      <ArrowRight size={11} color={isIn ? rc.dot : "#8A9299"} className="opacity-55" />
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="proto-badge">PROTOTYPE DATA</div>
          </div>
        );
      })()}

      {/* ── Preview + Notes ── */}
      {panel === "preview" && (() => {
        const node = nodes.find(n => n.id === panelNodeId);
        if (!node) return null;
        const cfg = TYPE_CFG[node.type];
        const hasPaging = node.fileExt === "pptx" || node.fileExt === "pdf";
        const totalPages = node.fileExt === "pptx" ? 12 : node.fileExt === "pdf" ? 8 : 1;
        return (
          <div className="right-panel fixed z-50 flex flex-col" style={{ top: 36, right: 0, bottom: 0, width: PANEL_W.preview }}>
            <div className="panel-header flex justify-between items-start">
              <div>
                <div className="text-[8.5px] font-bold uppercase tracking-[0.13em] text-[#8A9299] mb-1 select-none">Preview</div>
                <div className="text-[12px] font-semibold text-[#192837] select-none truncate max-w-[240px]">{node.title}</div>
                <div className="flex items-center gap-1.5 mt-1">
                  <div className="w-1.5 h-1.5 rounded-full" style={{ background: cfg.dot }} /><span className="text-[9px] select-none" style={{ color: cfg.dot }}>{cfg.label}</span>
                </div>
              </div>
              <button onClick={closeAllPanels} className="p-1.5 rounded-xl hover:bg-[rgba(25,40,55,0.06)] cursor-pointer text-[#8A9299]"><X size={13}/></button>
            </div>

            {/* Thumbnail area */}
            <div className="p-4">
              <div className="compare-thumb w-full" style={{ height: 180, background: `linear-gradient(145deg, ${cfg.tint.replace(/[\d.]+\)$/, "0.12)")}, #EEEEE9)`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8 }}>
                <FileIcon ext={node.fileExt} size={28} color={cfg.dot} />
                <span className="text-[10px] font-medium select-none" style={{ color: cfg.dot }}>
                  {hasPaging ? `Slide ${previewPage} of ${totalPages}` : node.title}
                </span>
              </div>
              {hasPaging && (
                <div className="flex items-center justify-center gap-3 mt-3">
                  <button disabled={previewPage <= 1} className="text-[#8A9299] disabled:opacity-30 cursor-pointer" onClick={() => setPreviewPage(p => Math.max(1, p - 1))}>
                    <ChevronDown size={14} className="rotate-90" />
                  </button>
                  <span className="text-[10px] text-[#8A9299] select-none tabular-nums">{previewPage} / {totalPages}</span>
                  <button disabled={previewPage >= totalPages} className="text-[#8A9299] disabled:opacity-30 cursor-pointer" onClick={() => setPreviewPage(p => Math.min(totalPages, p + 1))}>
                    <ChevronDown size={14} className="-rotate-90" />
                  </button>
                </div>
              )}
            </div>

            {/* Notes */}
            <div className="panel-section flex flex-col gap-2 flex-1">
              <div className="flex items-center gap-1.5 mb-1">
                <BookOpen size={10} color="#8A9299" />
                <span className="text-[9px] font-bold uppercase tracking-[0.12em] text-[#8A9299] select-none">
                  {hasPaging ? `Slide ${previewPage} Note` : "File Note"}
                </span>
              </div>
              <textarea
                className="flex-1 w-full resize-none text-[10.5px] text-[#192837] placeholder-[#8A9299] rounded-xl p-2.5 focus:outline-none"
                style={{ background: "rgba(25,40,55,0.03)", border: "1px solid rgba(25,40,55,0.07)", minHeight: 80 }}
                placeholder="添加备注…"
                value={notes[`${node.id}-${previewPage}`] || ""}
                onChange={e => setNotes(prev => ({ ...prev, [`${node.id}-${previewPage}`]: e.target.value }))}
              />
            </div>

            <div className="p-4 flex flex-col gap-2">
              <button className="liquid-chrome w-full py-2 rounded-xl text-[10px] font-semibold text-[#192837] cursor-pointer flex items-center justify-center gap-2"
                onClick={() => { closeAllPanels(); openPanel("command", node.id); }}>
                <Terminal size={11}/> 创建 Command
              </button>
              <button className="w-full py-2 rounded-xl text-[9.5px] font-medium cursor-pointer hover:bg-[rgba(25,40,55,0.04)] transition-colors text-center text-[#8A9299]"
                onClick={() => fireToast("已加入 Context 列表")}>
                + 加入 Context
              </button>
            </div>
            <div className="proto-badge">PROTOTYPE DATA</div>
          </div>
        );
      })()}

      {/* ── Command Panel ── */}
      {panel === "command" && (() => {
        const targetNode = nodes.find(n => n.id === commandTargetId) || nodes.find(n => n.id === "w1")!;
        const ctxNodes = nodes.filter(n => commandCtxIds.includes(n.id));
        const allCtxCandidates = nodes.filter(n => n.type === "context" || n.type === "source");
        return (
          <div className="right-panel fixed z-50 flex flex-col" style={{ top: 36, right: 0, bottom: 0, width: PANEL_W.command }}>
            <div className="panel-header flex justify-between items-center">
              <div>
                <div className="text-[8.5px] font-bold uppercase tracking-[0.13em] text-[#8A9299] mb-0.5 select-none">New Command</div>
                <div className="text-[12px] font-semibold text-[#192837] select-none">Define Task</div>
              </div>
              <button onClick={closeAllPanels} className="p-1.5 rounded-xl hover:bg-[rgba(25,40,55,0.06)] cursor-pointer text-[#8A9299]"><X size={13}/></button>
            </div>

            <div className="flex-1 overflow-y-auto">
              {/* Task input */}
              <div className="panel-section">
                <div className="text-[9px] font-bold uppercase tracking-[0.12em] text-[#8A9299] mb-2 select-none">Task</div>
                <textarea
                  className="w-full resize-none text-[11px] text-[#192837] placeholder-[#8A9299] rounded-xl p-3 focus:outline-none"
                  style={{ background: "rgba(25,40,55,0.035)", border: "1px solid rgba(25,40,55,0.07)", minHeight: 72 }}
                  placeholder="描述你想完成的任务… (Cmd+Enter 执行)"
                  value={commandTask}
                  onChange={e => setCommandTask(e.target.value)}
                  onKeyDown={e => { if ((e.metaKey || e.ctrlKey) && e.key === "Enter") { e.preventDefault(); startRun(); } }}
                />
              </div>

              {/* Target */}
              <div className="panel-section">
                <div className="text-[9px] font-bold uppercase tracking-[0.12em] text-[#8A9299] mb-2 select-none">Target</div>
                <div className="flex items-center gap-2.5 p-2.5 rounded-xl"
                  style={{ background: `${TYPE_CFG.working.tint}`, border: `1px solid rgba(58,127,213,0.15)` }}>
                  <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: TYPE_CFG.working.dot }} />
                  <FileIcon ext={targetNode.fileExt} size={12} />
                  <span className="text-[10.5px] font-medium text-[#192837] select-none truncate flex-1">{targetNode.title}</span>
                  <span className="text-[9px] select-none" style={{ color: TYPE_CFG.working.dot }}>Current</span>
                </div>
              </div>

              {/* Context */}
              <div className="panel-section">
                <div className="text-[9px] font-bold uppercase tracking-[0.12em] text-[#8A9299] mb-2 select-none">Context ({ctxNodes.length})</div>
                <div className="space-y-1">
                  {allCtxCandidates.map(n => {
                    const isIncl = commandCtxIds.includes(n.id);
                    const nc = TYPE_CFG[n.type];
                    return (
                      <button key={n.id}
                        className="w-full flex items-center gap-2.5 p-2 rounded-lg text-left cursor-pointer transition-colors"
                        style={{ background: isIncl ? nc.tint : "transparent", border: `1px solid ${isIncl ? "rgba(25,40,55,0.08)" : "transparent"}` }}
                        onClick={() => setCommandCtxIds(prev => prev.includes(n.id) ? prev.filter(id => id !== n.id) : [...prev, n.id])}>
                        <div className="w-4 h-4 rounded flex items-center justify-center flex-shrink-0"
                          style={{ background: isIncl ? nc.dot : "rgba(25,40,55,0.08)" }}>
                          {isIncl ? <Check size={9} color="white"/> : null}
                        </div>
                        <FileIcon ext={n.fileExt} size={11} />
                        <span className="text-[10px] font-medium text-[#192837] select-none truncate flex-1">{n.title}</span>
                        <span className="text-[8.5px] select-none" style={{ color: nc.dot }}>{nc.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Skill + Executor */}
              <div className="panel-section">
                <div className="text-[9px] font-bold uppercase tracking-[0.12em] text-[#8A9299] mb-2 select-none">Skill & Executor</div>
                <div className="flex gap-2">
                  <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg flex-1"
                    style={{ background: "rgba(115,66,226,0.07)", border: "1px solid rgba(115,66,226,0.12)" }}>
                    <Zap size={10} color="#7342E2" />
                    <span className="text-[9.5px] font-medium text-[#7342E2] select-none">Design Assistant</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg flex-1"
                    style={{ background: "rgba(25,40,55,0.04)", border: "1px solid rgba(25,40,55,0.08)" }}>
                    <Layers size={10} color="#8A9299" />
                    <span className="text-[9px] text-[#8A9299] select-none truncate">claude-sonnet-4-6</span>
                  </div>
                </div>
              </div>

              {/* Advanced (collapsed) */}
              <div className="p-4">
                <button className="flex items-center gap-1.5 text-[9px] text-[#8A9299] cursor-pointer hover:text-[#192837] transition-colors"
                  onClick={() => setAdvancedOpen(o => !o)}>
                  {advancedOpen ? <ChevronUp size={11}/> : <ChevronDown size={11}/>}
                  Advanced Settings
                </button>
                {advancedOpen && (
                  <div className="mt-3 p-3 rounded-xl space-y-2 fade-in"
                    style={{ background: "rgba(25,40,55,0.03)", border: "1px solid rgba(25,40,55,0.06)" }}>
                    {[["Temperature","0.7"],["Max tokens","4096"],["Tool use","Enabled"]].map(([k,v]) => (
                      <div key={k} className="flex justify-between items-center">
                        <span className="text-[9px] text-[#8A9299] select-none">{k}</span>
                        <span className="text-[9px] font-medium text-[#192837] select-none">{v}</span>
                      </div>
                    ))}
                    <div className="proto-badge" style={{ textAlign: "left", paddingLeft: 0 }}>PROTOTYPE DATA</div>
                  </div>
                )}
              </div>
            </div>

            {/* Run button */}
            <div className="p-4 pt-0">
              <button
                className="liquid-chrome-accent w-full py-3 rounded-2xl text-[11px] font-bold text-white cursor-pointer flex items-center justify-center gap-2"
                onClick={startRun}>
                <Play size={12}/>
                <span>Run  <span className="opacity-60 font-normal text-[9px]">Cmd+Enter</span></span>
              </button>
            </div>
            <div className="proto-badge">PROTOTYPE DATA · No execution connected</div>
          </div>
        );
      })()}

      {/* ── Activity Inspector ── */}
      {panel === "activity" && (() => {
        const stages: { key: RunStatus; label: string }[] = [
          { key: "queued",        label: "Queued" },
          { key: "running",       label: "Running" },
          { key: "waiting_input", label: "Waiting Input" },
          { key: "review",        label: "Reviewing" },
          { key: "completed",     label: "Completed" },
        ];
        const stageOrder = stages.map(s => s.key);
        const currentIdx = stageOrder.indexOf(runStatus);
        const artifactNode = pendingArtifactId ? nodes.find(n => n.id === pendingArtifactId) : null;
        return (
          <div className="right-panel fixed z-50 flex flex-col" style={{ top: 36, right: 0, bottom: 0, width: PANEL_W.activity }}>
            <div className="panel-header flex justify-between items-start">
              <div>
                <div className="text-[8.5px] font-bold uppercase tracking-[0.13em] text-[#8A9299] mb-0.5 select-none">Run Activity</div>
                <div className="text-[12px] font-semibold text-[#192837] select-none">Run #{runNumber}</div>
              </div>
              <button onClick={closeAllPanels} className="p-1.5 rounded-xl hover:bg-[rgba(25,40,55,0.06)] cursor-pointer text-[#8A9299]"><X size={13}/></button>
            </div>

            <div className="flex-1 overflow-y-auto">
              {/* Task */}
              <div className="panel-section">
                <div className="text-[9px] font-bold uppercase tracking-[0.12em] text-[#8A9299] mb-1.5 select-none">Task</div>
                <div className="text-[10.5px] text-[#192837] leading-relaxed select-none">
                  {commandTask || "Apply brand brief and client feedback to current proposal"}
                </div>
              </div>

              {/* Stage timeline */}
              <div className="panel-section">
                <div className="text-[9px] font-bold uppercase tracking-[0.12em] text-[#8A9299] mb-3 select-none">Stages</div>
                <div className="space-y-2.5">
                  {stages.map((s, i) => {
                    const done = currentIdx > i;
                    const active = currentIdx === i;
                    const pending = currentIdx < i;
                    return (
                      <div key={s.key} className="flex items-center gap-2.5">
                        <div className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0"
                          style={{ background: done ? "#4D9E4D" : active ? "#3A7FD5" : "rgba(25,40,55,0.08)" }}>
                          {done ? <Check size={9} color="white"/> : active ? <div className="w-2 h-2 rounded-full bg-white"/> : null}
                        </div>
                        <span className="text-[10px] select-none"
                          style={{ color: done ? "#4D9E4D" : active ? "#192837" : "#8A9299", fontWeight: active ? 600 : 400 }}>
                          {s.label}
                        </span>
                        {active && runStatus === "running" && <Loader size={10} color="#3A7FD5" className="spin ml-auto" />}
                        {active && runStatus === "waiting_input" && <span className="ml-auto text-[8.5px] text-[#C4703A] font-medium">Needs input</span>}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Changed files */}
              {(runStatus === "review" || runStatus === "completed") && (
                <div className="panel-section">
                  <div className="text-[9px] font-bold uppercase tracking-[0.12em] text-[#8A9299] mb-2 select-none">Changed Files</div>
                  <div className="flex items-center gap-2 p-2 rounded-lg" style={{ background: "rgba(147,112,232,0.06)", border: "1px solid rgba(147,112,232,0.12)" }}>
                    <Presentation size={11} color="#8B5CF6" />
                    <span className="text-[10px] font-medium text-[#192837] select-none flex-1">提案_v{runNumber}_AI.pptx</span>
                    <span className="text-[8.5px] rounded px-1.5 py-0.5 select-none" style={{ background: "rgba(147,112,232,0.12)", color: "#8B5CF6" }}>New</span>
                  </div>
                </div>
              )}

              {/* Artifact return */}
              {artifactNode && (
                <div className="panel-section">
                  <div className="text-[9px] font-bold uppercase tracking-[0.12em] text-[#8A9299] mb-2 select-none">Return Artifact</div>
                  <div className="flex items-center gap-2.5 p-2.5 rounded-xl cursor-pointer hover:bg-[rgba(25,40,55,0.04)] transition-colors"
                    style={{ border: "1px solid #D4845A44", background: "rgba(212,132,90,0.05)" }}
                    onClick={() => openPanel("compare", artifactNode.id)}>
                    <div className="w-1.5 h-1.5 rounded-full pending-ring" style={{ background: "#D4845A" }} />
                    <span className="text-[10px] font-medium text-[#192837] select-none flex-1">{artifactNode.title}</span>
                    <span className="text-[8.5px] text-[#D4845A] select-none">Pending Return →</span>
                  </div>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="p-4 flex flex-col gap-2">
              {(runStatus === "completed" || runStatus === "review") && artifactNode && (
                <button className="liquid-chrome-accent w-full py-2 rounded-xl text-[10px] font-bold text-white cursor-pointer flex items-center justify-center gap-2"
                  onClick={() => openPanel("compare", artifactNode.id)}>
                  <SplitSquareHorizontal size={11}/> Compare &amp; Review
                </button>
              )}
              <div className="flex gap-2">
                <button className="flex-1 py-2 rounded-xl text-[9.5px] font-medium cursor-pointer hover:bg-[rgba(25,40,55,0.06)] transition-colors flex items-center justify-center gap-1.5 text-[#8A9299]"
                  style={{ border: "1px solid rgba(25,40,55,0.08)" }}
                  onClick={() => { clearRunTimers(); setRunStatus("idle"); }}>
                  <X size={10}/> Cancel
                </button>
                <button className="flex-1 py-2 rounded-xl text-[9.5px] font-medium cursor-pointer hover:bg-[rgba(25,40,55,0.06)] transition-colors flex items-center justify-center gap-1.5 text-[#8A9299]"
                  style={{ border: "1px solid rgba(25,40,55,0.08)" }}
                  onClick={() => { clearRunTimers(); setPendingArtifactId(null); startRun(); }}>
                  <RotateCcw size={10}/> Retry
                </button>
              </div>
            </div>
            <div className="proto-badge">PROTOTYPE DATA · Simulated run state</div>
          </div>
        );
      })()}

      {/* ── Compare / Accept / Retry ── */}
      {panel === "compare" && (() => {
        const artNode = nodes.find(n => n.id === panelNodeId) || nodes.find(n => n.id === pendingArtifactId);
        const curNode = nodes.find(n => n.id === "w1");
        return (
          <div className="right-panel fixed z-50 flex flex-col" style={{ top: 36, right: 0, bottom: 0, width: PANEL_W.compare }}>
            <div className="panel-header flex justify-between items-center">
              <div>
                <div className="text-[8.5px] font-bold uppercase tracking-[0.13em] text-[#8A9299] mb-0.5 select-none">Compare Versions</div>
                <div className="text-[12px] font-semibold text-[#192837] select-none">Current → Draft</div>
              </div>
              <button onClick={closeAllPanels} className="p-1.5 rounded-xl hover:bg-[rgba(25,40,55,0.06)] cursor-pointer text-[#8A9299]"><X size={13}/></button>
            </div>

            {/* Diff summary */}
            <div className="px-4 py-3 flex items-center gap-3" style={{ borderBottom: "1px solid rgba(25,40,55,0.05)", background: "rgba(25,40,55,0.015)" }}>
              <span className="text-[9px] text-[#8A9299] select-none">Changes:</span>
              {[{ label: "+3 added", color: "#4D9E4D" }, { label: "~5 modified", color: "#3A7FD5" }, { label: "−1 removed", color: "#D4453A" }].map(d => (
                <span key={d.label} className="text-[9px] font-semibold px-2 py-0.5 rounded select-none"
                  style={{ background: `${d.color}14`, color: d.color }}>{d.label}</span>
              ))}
              <span className="ml-auto text-[9px] text-[#8A9299] select-none">Run #{runNumber - 1} · Draft · Pending</span>
            </div>

            {/* Side-by-side thumbnails */}
            <div className="flex flex-1 gap-3 p-4 overflow-hidden">
              {/* Current */}
              <div className="flex-1 flex flex-col gap-2">
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full" style={{ background: TYPE_CFG.working.dot }} />
                  <span className="text-[9.5px] font-semibold text-[#192837] select-none">{curNode?.title || "当前提案.pptx"}</span>
                  <span className="text-[8.5px] text-[#8A9299] select-none ml-auto">v6 · Current</span>
                </div>
                <div className="compare-thumb flex-1 flex flex-col items-center justify-center gap-2"
                  style={{ background: "linear-gradient(145deg, rgba(58,127,213,0.06), rgba(58,127,213,0.02))" }}>
                  <Presentation size={24} color={TYPE_CFG.working.dot} />
                  <span className="text-[9px] text-[#8A9299] select-none">Slide 1 of 12</span>
                </div>
                <div className="flex justify-center gap-1.5">
                  {[1,2,3].map(i => (
                    <div key={i} className="rounded" style={{ width: 24, height: 16, background: i===1?"rgba(58,127,213,0.2)":"rgba(25,40,55,0.08)" }}/>
                  ))}
                </div>
              </div>

              {/* Divider */}
              <div style={{ width: 1, background: "rgba(25,40,55,0.07)", flexShrink: 0 }} />

              {/* Draft */}
              <div className="flex-1 flex flex-col gap-2">
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full pulse" style={{ background: "#D4845A" }} />
                  <span className="text-[9.5px] font-semibold text-[#192837] select-none truncate">{artNode?.title || `提案_v${runNumber-1}_AI.pptx`}</span>
                  <span className="text-[8.5px] text-[#D4845A] select-none ml-auto">Draft</span>
                </div>
                <div className="compare-thumb flex-1 flex flex-col items-center justify-center gap-2"
                  style={{ background: "linear-gradient(145deg, rgba(147,112,232,0.08), rgba(147,112,232,0.03))" }}>
                  <Presentation size={24} color={TYPE_CFG.generated.dot} />
                  <span className="text-[9px] text-[#8A9299] select-none">Slide 1 of 15</span>
                  <div className="px-2 py-0.5 rounded text-[8px] font-medium select-none" style={{ background: "rgba(77,158,77,0.12)", color: "#4D9E4D" }}>
                    +3 new slides
                  </div>
                </div>
                <div className="flex justify-center gap-1.5">
                  {[1,2,3,4].map(i => (
                    <div key={i} className="rounded" style={{ width: 24, height: 16, background: i===3?"rgba(77,158,77,0.25)":"rgba(25,40,55,0.08)", border: i===3?"1px solid rgba(77,158,77,0.3)":"none" }}/>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="p-4 flex flex-col gap-2 pt-0">
              <button className="liquid-chrome-accent w-full py-3 rounded-2xl text-[11px] font-bold text-white cursor-pointer flex items-center justify-center gap-2"
                onClick={acceptArtifact}>
                <Check size={13}/> Accept as Current Version
              </button>
              <div className="flex gap-2">
                <button className="flex-1 py-2 rounded-xl text-[9.5px] font-medium cursor-pointer hover:bg-[rgba(25,40,55,0.06)] transition-colors flex items-center justify-center gap-1.5 text-[#8A9299]"
                  style={{ border: "1px solid rgba(25,40,55,0.08)" }}
                  onClick={() => openPanel("command", commandTargetId)}>
                  <Terminal size={10}/> Continue Editing
                </button>
                <button className="flex-1 py-2 rounded-xl text-[9.5px] font-medium cursor-pointer hover:bg-[rgba(25,40,55,0.06)] transition-colors flex items-center justify-center gap-1.5 text-[#8A9299]"
                  style={{ border: "1px solid rgba(25,40,55,0.08)" }}
                  onClick={() => fireToast("正在打开原生工具…")}>
                  <ExternalLink size={10}/> Open Native
                </button>
              </div>
              <div className="text-center">
                <span className="text-[8.5px] text-[#8A9299] select-none">
                  接受后将保留来源 Run 和 Revision 追溯 · Draft 约束仍需手动确认
                </span>
              </div>
            </div>
            <div className="proto-badge">PROTOTYPE DATA · Simulated diff</div>
          </div>
        );
      })()}

      {/* ══ WAITING INPUT MODAL ══════════════════════════════════ */}
      {runStatus === "waiting_input" && (
        <div className="fixed z-60 left-1/2 -translate-x-1/2 fade-in"
          style={{ top: 54, width: 380 }}>
          <div className="float-ctrl rounded-2xl p-5">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: "rgba(212,132,90,0.12)" }}>
                <AlertCircle size={15} color="#C4703A" />
              </div>
              <div>
                <div className="text-[9px] font-bold uppercase tracking-[0.13em] text-[#8A9299] mb-1 select-none">
                  Run #{runNumber} · Waiting Input
                </div>
                <div className="text-[12px] font-semibold text-[#192837] leading-snug select-none">
                  是否将结果保存为新版本?
                </div>
                <div className="text-[10px] text-[#8A9299] mt-1 select-none">
                  提案_v{runNumber}_AI.pptx 已生成，请选择保存方式
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <button className="liquid-chrome-accent w-full py-2.5 rounded-xl text-[10.5px] font-bold text-white cursor-pointer"
                onClick={() => respondWaiting("save")}>
                保存为新版本
              </button>
              <button className="w-full py-2.5 rounded-xl text-[10px] font-medium cursor-pointer hover:bg-[rgba(25,40,55,0.06)] transition-colors text-[#192837]"
                style={{ border: "1px solid rgba(25,40,55,0.09)" }}
                onClick={() => respondWaiting("overwrite")}>
                覆盖并保留 Revision
              </button>
              <button className="w-full py-2 text-[9.5px] text-[#8A9299] cursor-pointer hover:text-[#192837] transition-colors"
                onClick={() => respondWaiting("cancel")}>
                取消
              </button>
            </div>
            <div className="proto-badge mt-2">PROTOTYPE DATA · Demo State</div>
          </div>
        </div>
      )}

      {/* ══ TOAST ═══════════════════════════════════════════════ */}
      {toast && (
        <div className="fixed bottom-7 left-1/2 -translate-x-1/2 z-60 fade-up flex items-center gap-2 px-4 py-2 rounded-2xl select-none"
          style={{ background: "#192837", boxShadow: "0 4px 24px rgba(25,40,55,0.3)" }}>
          <Sparkles size={12} color="#9370E8" />
          <span className="text-[10.5px] font-medium text-white">{toast}</span>
        </div>
      )}
    </div>
  );
}
